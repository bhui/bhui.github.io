from distutils.core import setup
import py2exe
#setup(windows=["phpproxy.py"])
setup(console=["phpproxy.py"])
